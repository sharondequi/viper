#!/bin/sh
set -e

# Wait for DB if provided
if [ -n "$DB_HOST" ]; then
  echo "Waiting for DB $DB_HOST:$DB_PORT ..."
  until php -r "new PDO('mysql:host=' . getenv('DB_HOST') . ';port=' . (getenv('DB_PORT')?:3306) . ';dbname=' . (getenv('DB_DATABASE')?:''), getenv('DB_USERNAME'), getenv('DB_PASSWORD'));" >/dev/null 2>&1; do
    printf '.'
    sleep 2
  done
fi

php artisan key:generate --ansi || true
php artisan migrate --force || true

exec /usr/bin/supervisord -n -c /etc/supervisor/conf.d/supervisord.conf
